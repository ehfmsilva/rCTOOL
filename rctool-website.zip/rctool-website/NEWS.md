# rCTOOL 3.1.0

CRAN publication: 4 July 2026.

This website documents the published 3.1.0 package, including monthly simulations, soil and management configuration, temperature inputs, datasets, and the calibration module. These are the documented capabilities of this version; this page does not claim they were all introduced in this release.

The website examples are executed against the archived CRAN source. For ongoing development, see the [upstream repository](https://github.com/francagiannini/rCTOOL).
