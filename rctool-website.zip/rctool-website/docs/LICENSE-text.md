# License

    YEAR: 2024-2026
    COPYRIGHT HOLDER: Evandro H. Figueiredo Moura da Silva,João Serra, Franca Giannini Kurina
