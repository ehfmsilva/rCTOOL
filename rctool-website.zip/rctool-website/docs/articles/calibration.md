# Parameter calibration

The calibration module tests combinations of `f_hum_top` and `k_hum`
against annual observations of topsoil carbon. This demonstration uses
**synthetic observations derived from the example simulation**, so it
illustrates the workflow rather than independent model validation.

**Version 3.1.0 note:** the CRAN package contains
[`ctool_calibrate()`](https://ehfmsilva.github.io/rCTOOL/reference/ctool_calibrate.md),
but does not export it in its namespace. For this version, the example
explicitly accesses the internal function with
`rCTOOL:::ctool_calibrate()`. Internal interfaces may change between
releases.

Run the [getting started
example](https://ehfmsilva.github.io/rCTOOL/articles/getting-started.md)
first to create the configuration objects.

## Prepare observations

``` r

annual <- aggregate(C_topsoil ~ yrs, data = output, FUN = mean)
observed <- data.frame(Year = annual$yrs + 1, SOC_obs = annual$C_topsoil)
observed <- observed[observed$Year %in% c(1955, 1965, 1975, 1985, 1995), ]
observed
#>    Year  SOC_obs
#> 4  1955 56.10409
#> 14 1965 55.52216
#> 24 1975 54.62216
#> 34 1985 54.16431
#> 44 1995 53.38794
```

## Evaluate a parameter grid

``` r

calib <- rCTOOL:::ctool_calibrate(
  time_config = period, cinput_config = cin,
  temperature_config = scenario_temperature,
  management_config = management, soil_config = soil,
  observed = observed,
  f_hum_top = c(min = 0.20, max = 0.60, by = 0.10),
  k_hum = c(min = 0.0020, max = 0.0040, by = 0.0010),
  verbose = FALSE
)
summary(calib)
#> C-TOOL calibration summary
#> =========================
#> 
#> Calibration data:
#>   Observations: 5
#>   Tested combinations: 15
#> 
#> Calibrated parameters:
#>   f_hum_top
#>   k_hum
#> 
#> Parameter ranges:
#>   f_hum_top: 0.2 to 0.6 by 0.1
#>   k_hum: 0.002 to 0.004 by 0.001
#> 
#> Calibration settings:
#>   f_fom_top: 0.003
#>   cn_init: 10
#>   Ranking metric: d_index
#>   Minimize metric: FALSE
#> 
#> Best tested calibration:
#>  f_hum_top k_hum f_rom_top   d_index     RMSE        R2      Bias       MAE n
#>        0.4 0.004     0.597 0.8678099 1.038007 0.9781859 0.4954844 0.7633362 5
#> 
#> Current parameters versus best tested calibration:
#>                       Type   d_index     RMSE        R2       Bias       MAE n
#>  Current C-TOOL parameters 0.5768270 2.460624 0.9908253 -2.2206482 2.2206482 5
#>    Best tested calibration 0.8678099 1.038007 0.9781859  0.4954844 0.7633362 5
#>  f_hum_top  k_hum f_rom_top
#>      0.533 0.0028     0.405
#>      0.400 0.0040     0.597
#> 
#> Recommended parameter set:
#>                   Source f_hum_top k_hum f_rom_top   d_index     RMSE        R2
#>  Best tested calibration       0.4 0.004     0.597 0.8678099 1.038007 0.9781859
#>       Bias       MAE n
#>  0.4954844 0.7633362 5
#> 
#> Recommendation:
#>   Use the best tested calibration because it improved the selected performance metric compared with the current C-TOOL parameters.
```

## Read the result

``` r

calib$recommended_params
#>                    Source f_hum_top k_hum f_rom_top   d_index     RMSE
#> 1 Best tested calibration       0.4 0.004     0.597 0.8678099 1.038007
#>          R2      Bias       MAE n
#> 1 0.9781859 0.4954844 0.7633362 5
```

The output compares the current parameters with the best tested
combination. Metrics include RMSE, MAE, bias, R² and the Willmott index
of agreement. Consult the [calibration
reference](https://ehfmsilva.github.io/rCTOOL/reference/ctool_calibrate.md)
for the available settings and outputs.
