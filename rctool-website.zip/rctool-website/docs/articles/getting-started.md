# Getting started with rCTOOL

A complete example using the data distributed with rCTOOL 3.1.0. The
simulation runs monthly; the code below executes when this documentation
is built.

## Prepare the simulation

Five configurations describe the simulation period, annual carbon
inputs, management allocations, soil properties and monthly temperature.
Initial carbon is divided between fresh (FOM), humified (HUM) and
resistant (ROM) organic matter in topsoil and subsoil.

``` r

library(rCTOOL)
library(ggplot2)

data("basic_example")
data("scenario_temperature")

# Set the simulation period and carbon inputs
period <- define_timeperiod(yr_start = 1951, yr_end = 2019)
cin <- define_Cinputs(management_filepath = basic_example)
management <- management_config(
  management_filepath = basic_example,
  grain_monthly_allocation = rep(0, 12),
  grass_monthly_allocation = rep(0, 12),
  f_man_humification = 0.192
)

# Configure soil properties and turnover parameters
soil <- soil_config(
  Csoil_init = 105, Cproptop = 0.55,
  f_hum_top = 0.533, f_rom_top = 0.405,
  f_hum_sub = 0.387, f_rom_sub = 0.610,
  clay_top = 0.11, clay_sub = 0.20,
  phi = 0.035, f_co2 = 0.628, f_romi = 0.012,
  k_fom = 0.12, k_hum = 0.0028, k_rom = 3.85e-5,
  ftr = 0.0025
)

initial_pools <- initialize_soil_pools(cn = 12, soil_config = soil)
soil_pools <- c(initial_pools[[1]], initial_pools[[2]])

# Run the monthly simulation
output <- run_ctool(
  time_config = period, cin_config = cin,
  m_config = management, t_config = scenario_temperature,
  s_config = soil, soil_pools = soil_pools, verbose = FALSE
)
output$date <- as.Date(sprintf("%04d-%02d-01", output$yrs, output$mon))
```

## Inspect the inputs

``` r

head(basic_example, 2)
#>   mon  yrs id year Cin_top Cin_sub Cin_man manure_monthly_allocation
#> 1   1 1951  1 1951   3.566    0.39       0                         0
#> 2   2 1951  1 1952   3.566    0.39       0                         0
#>   plant_monthly_allocation
#> 1                        0
#> 2                        0
head(scenario_temperature, 2)
#>   month   yr     Tavg
#> 1     1 1951 0.890000
#> 2     2 1951 1.170714
```

## Inspect the output

Stocks are reported for topsoil (0–25 cm), subsoil (26–100 cm), and the
whole profile. See
[run_ctool()](https://ehfmsilva.github.io/rCTOOL/reference/run_ctool.md)
for the full interface.

``` r

head(as.data.frame(output)[c("mon", "yrs", "C_topsoil", "C_subsoil", "SOC_stock")])
#>   mon  yrs C_topsoil C_subsoil SOC_stock
#> 1   1 1951  57.60781  47.24813  104.8559
#> 2   2 1951  57.37211  47.24572  104.6178
#> 3   3 1951  57.09243  47.24246  104.3349
#> 4   4 1951  56.84625  47.25992  104.1062
#> 5   5 1951  56.59075  47.27697  103.8677
#> 6   6 1951  56.43326  47.29310  103.7264
```

## Plot the trajectory

``` r

ggplot(output, aes(date, C_topsoil)) +
  geom_line(colour = "#aa4e35", linewidth = 0.65) +
  labs(x = "Year", y = expression("Topsoil SOC (Mg C " * ha^{-1} * ")")) +
  theme_classic(base_size = 13)
```

![Simulated topsoil carbon stock over the Askov example
period.](getting-started_files/figure-html/trajectory-1.png)

## Continue

Use [scenario
comparisons](https://ehfmsilva.github.io/rCTOOL/articles/scenarios.md)
to change an input while keeping the remaining configuration fixed. The
[calibration
article](https://ehfmsilva.github.io/rCTOOL/articles/calibration.md)
explains how to evaluate a parameter grid.
