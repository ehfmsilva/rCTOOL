# Articles

### Guides

- [Getting started with
  rCTOOL](https://ehfmsilva.github.io/rCTOOL/articles/getting-started.md):
- [Comparing carbon-input
  scenarios](https://ehfmsilva.github.io/rCTOOL/articles/scenarios.md):
- [Parameter
  calibration](https://ehfmsilva.github.io/rCTOOL/articles/calibration.md):
