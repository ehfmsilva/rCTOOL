# Comparing carbon-input scenarios

This reproducible example compares the bundled Askov configuration with
an **illustrative 20% increase in plant carbon inputs**. It is a model
sensitivity exercise, not a measured treatment or a prediction of a
particular management practice.

First run the [getting started
example](https://ehfmsilva.github.io/rCTOOL/articles/getting-started.md).

## Change the carbon inputs

Keep soil, temperature and management settings fixed, and increase both
topsoil and subsoil plant inputs.

``` r

cin_higher <- cin
cin_higher$Cin_top <- cin$Cin_top * 1.20
cin_higher$Cin_sub <- cin$Cin_sub * 1.20

higher <- run_ctool(
  time_config = period, cin_config = cin_higher,
  m_config = management, t_config = scenario_temperature,
  s_config = soil, soil_pools = soil_pools, verbose = FALSE
)
comparison <- rbind(
  data.frame(date = output$date, SOC = output$C_topsoil,
             Scenario = "Reference inputs"),
  data.frame(date = output$date, SOC = higher$C_topsoil,
             Scenario = "20% higher plant C inputs")
)
```

## Compare trajectories

``` r

ggplot(comparison, aes(date, SOC, colour = Scenario)) +
  geom_line(linewidth = 0.65) +
  scale_colour_manual(values = c("#aa4e35", "#567150")) +
  labs(x = "Year", y = "Topsoil SOC (Mg C/ha)", colour = NULL) +
  theme_classic(base_size = 13) +
  theme(legend.position = "bottom")
```

![Two simulated topsoil SOC trajectories: reference inputs and twenty
percent higher plant carbon
inputs.](scenarios_files/figure-html/comparison-1.png)

The comparison isolates a change in carbon inputs. Real-world scenarios
require their own input assumptions and, where possible, validation
against observations.
