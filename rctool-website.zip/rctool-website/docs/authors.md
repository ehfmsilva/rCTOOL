# Authors and Citation

## Authors

- **Evandro H. Figueiredo Moura da Silva**. Author.

- **João Serra**. Author.

- **Franca Giannini-Kurina**. Author, maintainer.

## Citation

Source:
[`DESCRIPTION`](https://github.com/francagiannini/rCTOOL/blob/HEAD/DESCRIPTION)

Silva EHFMd, Serra J, Giannini-Kurina F (2026). *rCTOOL: Soil Organic
Carbon Turnover Modelling with 'C-TOOL'*.
[doi:10.32614/CRAN.package.rCTOOL](https://doi.org/10.32614/CRAN.package.rCTOOL).
R package version 3.1.0, <https://CRAN.R-project.org/package=rCTOOL>.

    @Manual{,
      title = {rCTOOL: Soil Organic Carbon Turnover Modelling with 'C-TOOL'},
      author = {Evandro H. Figueiredo Moura da Silva and João Serra and Franca Giannini-Kurina},
      year = {2026},
      note = {R package version 3.1.0},
      url = {https://CRAN.R-project.org/package=rCTOOL},
      doi = {10.32614/CRAN.package.rCTOOL},
    }
