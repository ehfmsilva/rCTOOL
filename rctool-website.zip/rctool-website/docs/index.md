# rCTOOL ![rCTOOL logo](reference/figures/rCTOOLicon.jpg)

rCTOOL brings the C-TOOL soil organic carbon model to R. Define carbon
inputs, management schedules, soil properties and temperature data, then
simulate soil carbon stocks, pools and fluxes in agricultural systems.

## Installation

Install the released version from
[CRAN](https://CRAN.R-project.org/package=rCTOOL):

``` r

install.packages("rCTOOL")
```

Install the development version from
[GitHub](https://github.com/francagiannini/rCTOOL):

``` r

# install.packages("pak")
pak::pkg_install("francagiannini/rCTOOL")
```

## Example

This example uses the bundled Askov data from Denmark. It follows a
spring barley treatment with straw incorporation and simulates monthly
soil carbon dynamics from 1951 to 2019. See the [getting started
guide](https://ehfmsilva.github.io/rCTOOL/articles/getting-started.md)
for the inputs and results in detail.

``` r

library(rCTOOL)
library(ggplot2)

data("basic_example")
data("scenario_temperature")

# Set the simulation period and carbon inputs
period <- define_timeperiod(yr_start = 1951, yr_end = 2019)
cin <- define_Cinputs(management_filepath = basic_example)
management <- management_config(
  management_filepath = basic_example,
  grain_monthly_allocation = rep(0, 12),
  grass_monthly_allocation = rep(0, 12),
  f_man_humification = 0.192
)

# Configure soil properties and turnover parameters
soil <- soil_config(
  Csoil_init = 105, Cproptop = 0.55,
  f_hum_top = 0.533, f_rom_top = 0.405,
  f_hum_sub = 0.387, f_rom_sub = 0.610,
  clay_top = 0.11, clay_sub = 0.20,
  phi = 0.035, f_co2 = 0.628, f_romi = 0.012,
  k_fom = 0.12, k_hum = 0.0028, k_rom = 3.85e-5,
  ftr = 0.0025
)

initial_pools <- initialize_soil_pools(cn = 12, soil_config = soil)
soil_pools <- c(initial_pools[[1]], initial_pools[[2]])

# Run the monthly simulation
output <- run_ctool(
  time_config = period, cin_config = cin,
  m_config = management, t_config = scenario_temperature,
  s_config = soil, soil_pools = soil_pools, verbose = FALSE
)
output$date <- as.Date(sprintf("%04d-%02d-01", output$yrs, output$mon))
```

Plot the simulated topsoil carbon stock:

``` r

ggplot(output, aes(date, C_topsoil)) +
  geom_line(colour = "#aa4e35", linewidth = 0.65) +
  labs(x = "Year", y = expression("Topsoil SOC (Mg C " * ha^{-1} * ")")) +
  theme_classic(base_size = 13)
```

![Simulated monthly topsoil organic carbon stock at Askov from 1951 to
2019.](reference/figures/site-basic-soc.png)

[Download the complete R
script](https://ehfmsilva.github.io/rCTOOL/quick-start.R).

## Explore rCTOOL

- [Get
  started](https://ehfmsilva.github.io/rCTOOL/articles/getting-started.md):
  configure and run a complete monthly simulation.
- [Compare
  scenarios](https://ehfmsilva.github.io/rCTOOL/articles/scenarios.md):
  explore the effect of changing plant carbon inputs.
- [Parameter
  calibration](https://ehfmsilva.github.io/rCTOOL/articles/calibration.md):
  work with observed SOC and the calibration grid.
- [Function
  reference](https://ehfmsilva.github.io/rCTOOL/reference/index.md):
  arguments, return values and examples for the package functions.

## References

The model framework is described by Petersen, Olesen and Heidmann
(2002), [A flexible tool for simulation of soil carbon
turnover](https://doi.org/10.1016/S0304-3800(02)00034-0), and
Taghizadeh-Toosi et al. (2014), [C-TOOL: A simple model for simulating
whole-profile carbon storage in temperate agricultural
soils](https://doi.org/10.1016/j.ecolmodel.2014.08.016).

For the rCTOOL validation study, see [Modelling and validating soil
carbon dynamics at the long-term plot scale using the rCTOOL R
package](https://doi.org/10.1016/j.envsoft.2024.106229).

The Askov experiment is described in [Jensen et
al. (2021)](https://doi.org/10.1016/j.fcr.2021.108228) and [Jensen et
al. (2022)](https://doi.org/10.1111/ejss.13173).
