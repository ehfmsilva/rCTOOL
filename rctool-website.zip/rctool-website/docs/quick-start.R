library(rCTOOL)
library(ggplot2)

data("basic_example")
data("scenario_temperature")

# Set the simulation period and carbon inputs
period <- define_timeperiod(yr_start = 1951, yr_end = 2019)
cin <- define_Cinputs(management_filepath = basic_example)
management <- management_config(
  management_filepath = basic_example,
  grain_monthly_allocation = rep(0, 12),
  grass_monthly_allocation = rep(0, 12),
  f_man_humification = 0.192
)

# Configure soil properties and turnover parameters
soil <- soil_config(
  Csoil_init = 105, Cproptop = 0.55,
  f_hum_top = 0.533, f_rom_top = 0.405,
  f_hum_sub = 0.387, f_rom_sub = 0.610,
  clay_top = 0.11, clay_sub = 0.20,
  phi = 0.035, f_co2 = 0.628, f_romi = 0.012,
  k_fom = 0.12, k_hum = 0.0028, k_rom = 3.85e-5,
  ftr = 0.0025
)

initial_pools <- initialize_soil_pools(cn = 12, soil_config = soil)
soil_pools <- c(initial_pools[[1]], initial_pools[[2]])

# Run the monthly simulation
output <- run_ctool(
  time_config = period, cin_config = cin,
  m_config = management, t_config = scenario_temperature,
  s_config = soil, soil_pools = soil_pools, verbose = FALSE
)
output$date <- as.Date(sprintf("%04d-%02d-01", output$yrs, output$mon))
