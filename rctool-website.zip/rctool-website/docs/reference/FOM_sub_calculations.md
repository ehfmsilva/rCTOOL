# FOM_sub_calculations

Calculate FOM decomposition and carbon fluxes in the subsoil layer.

## Usage

``` r
FOM_sub_calculations(FOM_sub_t, month, t_avg, amplitude, s_config)
```

## Arguments

- FOM_sub_t:

  Numeric. Carbon content in FOM subsoil pool (Mg C ha-1).

- month:

  Integer. Month index (1–12).

- t_avg:

  Numeric. Monthly mean air temperature (°C).

- amplitude:

  Numeric. Annual historical temperature amplitude used in the soil
  temperature function.

- s_config:

  List. Soil configuration parameters

## Value

A list with updated pool values and fluxes for FOM subsoil layer.

## Examples

``` r
FOM_sub_calculations(
  FOM_sub_t = 10,
  month = 7,
  t_avg = 15,
  amplitude = 10,
  s_config = soil_config()
)
#> $FOM_sub
#> [1] 7.853533
#> 
#> $FOM_sub_decomposition
#> [1] -2.146467
#> 
#> $substrate_FOM_decomp_sub
#> [1] 2.146467
#> 
#> $FOM_humified_sub
#> [1] 0.4370403
#> 
#> $em_CO2_FOM_sub
#> [1] 1.709426
#> 
```
