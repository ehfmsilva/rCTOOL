# FOM_top_calculations

Calculate FOM decomposition and carbon fluxes in the topsoil layer.

## Usage

``` r
FOM_top_calculations(
  FOM_top_t,
  month,
  t_avg = t_avg,
  amplitude = amplitude,
  s_config
)
```

## Arguments

- FOM_top_t:

  Numeric. Carbon content in FOM top pool (Mg C ha-1).

- month:

  Integer. Month index (1–12).

- t_avg:

  Numeric. Monthly mean air temperature (°C).

- amplitude:

  Numeric. Annual historical temperature amplitude used in the soil
  temperature function.

- s_config:

  List. Soil configuration parameters.

## Value

A list with updated pool values and fluxes for FOM topsoil layer.

## Examples

``` r
FOM_top_calculations(
  FOM_top_t = 10,
  month = 7,
  t_avg = 15,
  amplitude = 10,
  s_config = soil_config()
)
#> $FOM_top
#> [1] 8.216685
#> 
#> $FOM_top_decomposition
#> [1] -1.783315
#> 
#> $substrate_FOM_decomp_top
#> [1] 1.783315
#> 
#> $FOM_humified_top
#> [1] 0.3351884
#> 
#> $em_CO2_FOM_top
#> [1] 1.443668
#> 
#> $FOM_tr
#> [1] 0.004458286
#> 
```
