# HUM_sub_calculations

Calculate HUM decomposition and carbon fluxes in the subsoil layer.

## Usage

``` r
HUM_sub_calculations(HUM_sub_t, month, t_avg, amplitude, s_config)
```

## Arguments

- HUM_sub_t:

  Numeric. Carbon content in the HUM subsoil pool (Mg C ha-1).

- month:

  Integer. Month index (1-12).

- t_avg:

  Numeric. Monthly mean air temperature (degrees C).

- amplitude:

  Numeric. Annual historical temperature amplitude used in the soil
  temperature function.

- s_config:

  List. Soil configuration parameters.

## Value

A list with updated HUM subsoil pool values and associated fluxes.

## Examples

``` r
# \donttest{
HUM_sub_calculations(
  HUM_sub_t = 20,
  month = 7,
  t_avg = 15,
  amplitude = 10,
  s_config = soil_config()
)
#> $HUM_sub
#> [1] 19.93589
#> 
#> $HUM_sub_decomposition
#> [1] -0.1001684
#> 
#> $substrate_HUM_decomp_sub
#> [1] 0.1001684
#> 
#> $HUM_romified_sub
#> [1] 0.001202021
#> 
#> $em_CO2_HUM_sub
#> [1] 0.06290578
#> 
# }
```
