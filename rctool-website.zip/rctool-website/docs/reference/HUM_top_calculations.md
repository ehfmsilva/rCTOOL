# HUM_top_calculations

Calculate HUM decomposition and carbon fluxes in the topsoil layer.

## Usage

``` r
HUM_top_calculations(
  HUM_top_t,
  month,
  t_avg = t_avg,
  amplitude = amplitude,
  s_config
)
```

## Arguments

- HUM_top_t:

  Numeric. Carbon content in the HUM topsoil pool (Mg C ha-1).

- month:

  Integer. Month index (1-12).

- t_avg:

  Numeric. Monthly mean air temperature (degrees C).

- amplitude:

  Numeric. Annual historical temperature amplitude used in the soil
  temperature function.

- s_config:

  List. Soil configuration parameters.

## Value

A list with updated HUM topsoil pool values and associated fluxes.

## Examples

``` r
# \donttest{
HUM_top_calculations(
  HUM_top_t = 20,
  month = 7,
  t_avg = 15,
  amplitude = 10,
  s_config = soil_config()
)
#> $HUM_top
#> [1] 19.91678
#> 
#> $HUM_top_decomposition
#> [1] -0.08322135
#> 
#> $substrate_HUM_decomp_top
#> [1] 0.08322135
#> 
#> $HUM_romified_top
#> [1] 0.0009986561
#> 
#> $em_CO2_HUM_top
#> [1] 0.052263
#> 
#> $HUM_tr
#> [1] 0.02995968
#> 
# }
```
