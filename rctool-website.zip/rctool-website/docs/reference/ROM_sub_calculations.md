# ROM_sub_calculations

Calculate ROM decomposition and carbon fluxes in the subsoil layer.

## Usage

``` r
ROM_sub_calculations(ROM_sub_t, month, t_avg, amplitude, s_config)
```

## Arguments

- ROM_sub_t:

  Numeric. Carbon content in the ROM subsoil pool (Mg C ha-1).

- month:

  Integer. Month index (1-12).

- t_avg:

  Numeric. Monthly mean air temperature (degrees C).

- amplitude:

  Numeric. Annual historical temperature amplitude used in the soil
  temperature function.

- s_config:

  List. Soil configuration parameters.

## Value

A list with updated ROM subsoil pool values and associated fluxes.

## Examples

``` r
# \donttest{
ROM_sub_calculations(
  ROM_sub_t = 10,
  month = 7,
  t_avg = 15,
  amplitude = 10,
  s_config = soil_config()
)
#> $ROM_sub
#> [1] 9.999568
#> 
#> $ROM_sub_decomposition
#> [1] -0.000688658
#> 
#> $substrate_ROM_decomp_sub
#> [1] 0.000688658
#> 
#> $em_CO2_ROM_sub
#> [1] 0.0004324773
#> 
# }
```
