# ROM_top_calculations

Calculate ROM decomposition and carbon fluxes in the topsoil layer.

## Usage

``` r
ROM_top_calculations(ROM_top_t, month, t_avg, amplitude, s_config)
```

## Arguments

- ROM_top_t:

  Numeric. Carbon content in the ROM topsoil pool (Mg C ha-1).

- month:

  Integer. Month index (1-12).

- t_avg:

  Numeric. Monthly mean air temperature (degrees C).

- amplitude:

  Numeric. Annual historical temperature amplitude used in the soil
  temperature function.

- s_config:

  List. Soil configuration parameters.

## Value

A list with updated ROM topsoil pool values and associated fluxes.

## Examples

``` r
# \donttest{
ROM_top_calculations(
  ROM_top_t = 10,
  month = 7,
  t_avg = 15,
  amplitude = 10,
  s_config = soil_config()
)
#> $ROM_top
#> [1] 9.999639
#> 
#> $ROM_top_decomposition
#> [1] -0.0005721467
#> 
#> $substrate_ROM_decomp_top
#> [1] 0.0005721467
#> 
#> $em_CO2_ROM_top
#> [1] 0.0003593082
#> 
#> $ROM_tr
#> [1] 1.430367e-06
#> 
# }
```
