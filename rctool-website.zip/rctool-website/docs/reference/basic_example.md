# Basic rCTOOL example dataset

Example dataset used to demonstrate a basic rCTOOL simulation.

## Usage

``` r
basic_example
```

## Format

A data frame.

## Source

Internal example dataset distributed with rCTOOL.
