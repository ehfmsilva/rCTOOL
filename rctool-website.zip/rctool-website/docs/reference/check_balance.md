# check_balance

Check carbon balance consistency of a simulation.

## Usage

``` r
check_balance(ctool_output, cin_config, s_config)
```

## Arguments

- ctool_output:

  Output from turnover model.

- cin_config:

  Carbon input configuration.

- s_config:

  Soil configuration.

## Value

The input \`ctool_output\` data.frame, returned unchanged after checking
carbon balance consistency.

## Details

Computes the balance between initial soil carbon, cumulative carbon
inputs, final carbon stocks and cumulative CO2 emissions. The balance
should be zero or very close to zero.
