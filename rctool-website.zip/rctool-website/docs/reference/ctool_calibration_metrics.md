# Calculate C-TOOL calibration metrics

Calculates performance metrics between observed and simulated SOC
values.

## Usage

``` r
ctool_calibration_metrics(observed, simulated)
```

## Arguments

- observed:

  Numeric vector with observed values.

- simulated:

  Numeric vector with simulated values.

## Value

A data frame with \`d_index\`, \`RMSE\`, \`R2\`, \`Bias\`, \`MAE\`, and
\`n\`.

## Details

The returned \`d_index\` is the Willmott index of agreement.

## References

Willmott, C. J. (1981). On the validation of models. Physical Geography,
2(2), 184-194.

## Examples

``` r
ctool_calibration_metrics(
  observed = c(50, 52, 55),
  simulated = c(49, 53, 54)
)
#>     d_index RMSE        R2       Bias MAE n
#> 1 0.9421842    1 0.8120301 -0.3333333   1 3
```
