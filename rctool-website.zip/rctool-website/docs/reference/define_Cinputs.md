# define_Cinputs

Prepare annual carbon input (from plants and/or manure) configuration.

## Usage

``` r
define_Cinputs(
  management_filepath = NULL,
  Cin_top = NULL,
  Cin_sub = NULL,
  Cin_man = NULL,
  time_config = NULL
)
```

## Arguments

- management_filepath:

  Either a filepath to a management template or a data.frame containing
  \`Cin_top\`, \`Cin_sub\` and \`Cin_man\`.

- Cin_top:

  Annual carbon input from plant residues in the topsoil.

- Cin_sub:

  Annual carbon input from plant residues in the subsoil.

- Cin_man:

  Annual carbon input from manure.

- time_config:

  Time configuration object returned by \`define_timeperiod()\`

## Value

A list containing \`Cin_top\`, \`Cin_sub\` and \`Cin_man\`.

## Examples

``` r
time_config <- define_timeperiod(yr_start = 2006, yr_end = 2008)
define_Cinputs(
  Cin_top = c(2, 2, 2),
  Cin_sub = c(0.5, 0.5, 0.5),
  Cin_man = c(1, 1, 1),
  time_config = time_config
)
#> $Cin_top
#> [1] 2 2 2
#> 
#> $Cin_sub
#> [1] 0.5 0.5 0.5
#> 
#> $Cin_man
#> [1] 1 1 1
#> 
```
