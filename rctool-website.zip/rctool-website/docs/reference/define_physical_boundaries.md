# define_physical_boundaries

Check whether a parameter value lies within specified physical bounds.

## Usage

``` r
define_physical_boundaries(value, min_limit, max_limit)
```

## Arguments

- value:

  parameter value

- min_limit:

  Minimum allowed value.

- max_limit:

  Maximum allowed value.

## Value

The input value if it lies within the specified physical bounds.

## Examples

``` r
define_physical_boundaries(0.3, 0, 1)
#> [1] 0.3
```
