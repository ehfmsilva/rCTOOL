# define_timeperiod

Create the monthly simulation time structure.

## Usage

``` r
define_timeperiod(yr_start, yr_end)
```

## Arguments

- yr_start:

  Initial simulation year.

- yr_end:

  Final nd simulation year.

## Value

A list with two elements: \`timeperiod\`, a data.frame containing
monthly timesteps, years and annual timestep identifiers; and \`steps\`,
the total number of simulated months.

## Examples

``` r
 define_timeperiod(yr_start=2006, yr_end=2010)
#> $timeperiod
#>    mon  yrs id
#> 1    1 2006  1
#> 2    2 2006  1
#> 3    3 2006  1
#> 4    4 2006  1
#> 5    5 2006  1
#> 6    6 2006  1
#> 7    7 2006  1
#> 8    8 2006  1
#> 9    9 2006  1
#> 10  10 2006  1
#> 11  11 2006  1
#> 12  12 2006  1
#> 13   1 2007  2
#> 14   2 2007  2
#> 15   3 2007  2
#> 16   4 2007  2
#> 17   5 2007  2
#> 18   6 2007  2
#> 19   7 2007  2
#> 20   8 2007  2
#> 21   9 2007  2
#> 22  10 2007  2
#> 23  11 2007  2
#> 24  12 2007  2
#> 25   1 2008  3
#> 26   2 2008  3
#> 27   3 2008  3
#> 28   4 2008  3
#> 29   5 2008  3
#> 30   6 2008  3
#> 31   7 2008  3
#> 32   8 2008  3
#> 33   9 2008  3
#> 34  10 2008  3
#> 35  11 2008  3
#> 36  12 2008  3
#> 37   1 2009  4
#> 38   2 2009  4
#> 39   3 2009  4
#> 40   4 2009  4
#> 41   5 2009  4
#> 42   6 2009  4
#> 43   7 2009  4
#> 44   8 2009  4
#> 45   9 2009  4
#> 46  10 2009  4
#> 47  11 2009  4
#> 48  12 2009  4
#> 49   1 2010  5
#> 50   2 2010  5
#> 51   3 2010  5
#> 52   4 2010  5
#> 53   5 2010  5
#> 54   6 2010  5
#> 55   7 2010  5
#> 56   8 2010  5
#> 57   9 2010  5
#> 58  10 2010  5
#> 59  11 2010  5
#> 60  12 2010  5
#> 
#> $steps
#> [1] 60
#> 
```
