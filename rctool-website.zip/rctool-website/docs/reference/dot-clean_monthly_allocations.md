# .clean_monthly_allocations

Clean and harmonize monthly allocation inputs.

## Usage

``` r
.clean_monthly_allocations(m_config)
```

## Arguments

- m_config:

  Management configuration list.

## Value

A management configuration list containing \`plant_monthly_allocation\`.

## Details

Reads management configuration with monthly allocation vectors and
returns a configuration containing \`plant_monthly_allocation\`.

Depending on the user input: - if plant, grain and grass allocations are
all provided, plant allocation is recalculated as grain plus grass - if
only one allocation is provided, it is treated as plant allocation - if
two allocations are provided, they must correspond to grain and grass;
otherwise an error is returned
