# .decay

Calculate soil carbon loss by first-order decomposition.

## Usage

``` r
.decay(CO_t, k, tempCoefficient)
```

## Arguments

- CO_t:

  Carbon amount in the pool at time t.

- k:

  First-order decomposition rate constant.

- tempCoefficient:

  Temperature response coefficient.

## Value

Carbon change due to decomposition during the timestep.
