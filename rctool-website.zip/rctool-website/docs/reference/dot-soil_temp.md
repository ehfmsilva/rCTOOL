# .soil_temp

.soil_temp

## Usage

``` r
.soil_temp(depth, month, T_ave, Amplitude, th_diff)
```

## Arguments

- depth:

  Soil layer reference depth in cm. In the default C-TOOL configuration,
  the model operates with two fixed layers: topsoil (25 cm) and subsoil
  (100 cm).

- month:

  Month index (1 to 12).

- T_ave:

  Monthly mean air temperature.

- Amplitude:

  Annual temperature amplitude used in the soil temperature equation.

- th_diff:

  Thermal diffusivity.

## Value

Soil temperature at the midpoint of the soil layer for the specified
monthly timestep.
