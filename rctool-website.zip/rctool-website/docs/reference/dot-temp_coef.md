# .temp_coef

Calculate the temperature response coefficient for carbon decomposition.

## Usage

``` r
.temp_coef(T_zt)
```

## Arguments

- T_zt:

  Soil temperature at depth z and time t.

## Value

Temperature response coefficient for carbon decomposition.
