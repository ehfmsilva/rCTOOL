# export_management_template

Exports a template that can be used to provide management inputs for the
model. The exported file includes monthly allocation variables and
carbon input columns initialized with zeros, so they can be filled by
the user before being read by the model.

## Usage

``` r
export_management_template(yr_start, yr_end, filepath)
```

## Arguments

- yr_start:

  Initial simulation year.

- yr_end:

  Final simulation year.

- filepath:

  Filepath where management template will be exported.

## Value

The exported template as a data.frame.

## Details

Users should keep only the columns relevant to their workflow and avoid
double accounting among allocation variables. For example, when
\`plant_monthly_allocation\` is used, grain and grass allocation columns
should not be used simultaneously.

If monthly carbon inputs are provided directly, additional allocation
columns may not be needed. These consistency checks are not enforced
automatically and must be handled by the user when preparing the input
file.

## Examples

``` r
path <- tempfile(fileext = ".csv")
export_management_template(2006, 2010, path)
```
