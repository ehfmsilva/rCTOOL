# Package index

## Run a simulation

- [`rCTOOL`](https://ehfmsilva.github.io/rCTOOL/reference/rCTOOL-package.md)
  [`rCTOOL-package`](https://ehfmsilva.github.io/rCTOOL/reference/rCTOOL-package.md)
  : rCTOOL package
- [`run_ctool()`](https://ehfmsilva.github.io/rCTOOL/reference/run_ctool.md)
  : run_ctool
- [`define_timeperiod()`](https://ehfmsilva.github.io/rCTOOL/reference/define_timeperiod.md)
  : define_timeperiod
- [`define_Cinputs()`](https://ehfmsilva.github.io/rCTOOL/reference/define_Cinputs.md)
  : define_Cinputs
- [`management_config()`](https://ehfmsilva.github.io/rCTOOL/reference/management_config.md)
  : management_config
- [`soil_config()`](https://ehfmsilva.github.io/rCTOOL/reference/soil_config.md)
  : soil_config
- [`initialize_soil_pools()`](https://ehfmsilva.github.io/rCTOOL/reference/initialize_soil_pools.md)
  : initialize_soil_pools

## Temperature and input data

- [`set_monthly_temperature_data()`](https://ehfmsilva.github.io/rCTOOL/reference/set_monthly_temperature_data.md)
  : set_monthly_temperature_data
- [`set_monthly_temperature_data_historical_amplitude()`](https://ehfmsilva.github.io/rCTOOL/reference/set_monthly_temperature_data_historical_amplitude.md)
  : set_monthly_temperature_data_historical_amplitude
- [`export_management_template()`](https://ehfmsilva.github.io/rCTOOL/reference/export_management_template.md)
  : export_management_template
- [`basic_example`](https://ehfmsilva.github.io/rCTOOL/reference/basic_example.md)
  : Basic rCTOOL example dataset
- [`scenario`](https://ehfmsilva.github.io/rCTOOL/reference/scenario.md)
  : rCTOOL scenario example dataset
- [`scenario_temperature`](https://ehfmsilva.github.io/rCTOOL/reference/scenario_temperature.md)
  : rCTOOL scenario temperature dataset

## Calibration and diagnostics

- [`ctool_calibrate()`](https://ehfmsilva.github.io/rCTOOL/reference/ctool_calibrate.md)
  : Calibrate C-TOOL using observed topsoil SOC
- [`ctool_calibration_metrics()`](https://ehfmsilva.github.io/rCTOOL/reference/ctool_calibration_metrics.md)
  : Calculate C-TOOL calibration metrics
- [`check_balance()`](https://ehfmsilva.github.io/rCTOOL/reference/check_balance.md)
  : check_balance

## Model processes

- [`turnover()`](https://ehfmsilva.github.io/rCTOOL/reference/turnover.md)
  : turnover
- [`define_physical_boundaries()`](https://ehfmsilva.github.io/rCTOOL/reference/define_physical_boundaries.md)
  : define_physical_boundaries
- [`FOM_sub_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/FOM_sub_calculations.md)
  : FOM_sub_calculations
- [`FOM_top_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/FOM_top_calculations.md)
  : FOM_top_calculations
- [`HUM_sub_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/HUM_sub_calculations.md)
  : HUM_sub_calculations
- [`HUM_top_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/HUM_top_calculations.md)
  : HUM_top_calculations
- [`ROM_sub_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/ROM_sub_calculations.md)
  : ROM_sub_calculations
- [`ROM_top_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/ROM_top_calculations.md)
  : ROM_top_calculations
- [`update_monthly_FOM_sub()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_FOM_sub.md)
  : update_monthly_FOM_sub
- [`update_monthly_FOM_top()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_FOM_top.md)
  : update_monthly_FOM_top
- [`update_monthly_HUM_sub()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_HUM_sub.md)
  : update_monthly_HUM_sub
- [`update_monthly_HUM_top()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_HUM_top.md)
  : update_monthly_HUM_top
- [`update_monthly_ROM_sub()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_ROM_sub.md)
  : update_monthly_ROM_sub
- [`update_monthly_ROM_top()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_ROM_top.md)
  : update_monthly_ROM_top

## Internal helpers

- [`basic_example`](https://ehfmsilva.github.io/rCTOOL/reference/basic_example.md)
  : Basic rCTOOL example dataset
- [`check_balance()`](https://ehfmsilva.github.io/rCTOOL/reference/check_balance.md)
  : check_balance
- [`ctool_calibrate()`](https://ehfmsilva.github.io/rCTOOL/reference/ctool_calibrate.md)
  : Calibrate C-TOOL using observed topsoil SOC
- [`ctool_calibration_metrics()`](https://ehfmsilva.github.io/rCTOOL/reference/ctool_calibration_metrics.md)
  : Calculate C-TOOL calibration metrics
- [`define_Cinputs()`](https://ehfmsilva.github.io/rCTOOL/reference/define_Cinputs.md)
  : define_Cinputs
- [`define_physical_boundaries()`](https://ehfmsilva.github.io/rCTOOL/reference/define_physical_boundaries.md)
  : define_physical_boundaries
- [`define_timeperiod()`](https://ehfmsilva.github.io/rCTOOL/reference/define_timeperiod.md)
  : define_timeperiod
- [`.clean_monthly_allocations()`](https://ehfmsilva.github.io/rCTOOL/reference/dot-clean_monthly_allocations.md)
  : .clean_monthly_allocations
- [`.decay()`](https://ehfmsilva.github.io/rCTOOL/reference/dot-decay.md)
  : .decay
- [`.soil_temp()`](https://ehfmsilva.github.io/rCTOOL/reference/dot-soil_temp.md)
  : .soil_temp
- [`.temp_coef()`](https://ehfmsilva.github.io/rCTOOL/reference/dot-temp_coef.md)
  : .temp_coef
- [`export_management_template()`](https://ehfmsilva.github.io/rCTOOL/reference/export_management_template.md)
  : export_management_template
- [`FOM_sub_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/FOM_sub_calculations.md)
  : FOM_sub_calculations
- [`FOM_top_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/FOM_top_calculations.md)
  : FOM_top_calculations
- [`HUM_sub_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/HUM_sub_calculations.md)
  : HUM_sub_calculations
- [`HUM_top_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/HUM_top_calculations.md)
  : HUM_top_calculations
- [`initialize_soil_pools()`](https://ehfmsilva.github.io/rCTOOL/reference/initialize_soil_pools.md)
  : initialize_soil_pools
- [`management_config()`](https://ehfmsilva.github.io/rCTOOL/reference/management_config.md)
  : management_config
- [`ROM_sub_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/ROM_sub_calculations.md)
  : ROM_sub_calculations
- [`ROM_top_calculations()`](https://ehfmsilva.github.io/rCTOOL/reference/ROM_top_calculations.md)
  : ROM_top_calculations
- [`run_ctool()`](https://ehfmsilva.github.io/rCTOOL/reference/run_ctool.md)
  : run_ctool
- [`scenario`](https://ehfmsilva.github.io/rCTOOL/reference/scenario.md)
  : rCTOOL scenario example dataset
- [`scenario_temperature`](https://ehfmsilva.github.io/rCTOOL/reference/scenario_temperature.md)
  : rCTOOL scenario temperature dataset
- [`set_monthly_temperature_data()`](https://ehfmsilva.github.io/rCTOOL/reference/set_monthly_temperature_data.md)
  : set_monthly_temperature_data
- [`set_monthly_temperature_data_historical_amplitude()`](https://ehfmsilva.github.io/rCTOOL/reference/set_monthly_temperature_data_historical_amplitude.md)
  : set_monthly_temperature_data_historical_amplitude
- [`soil_config()`](https://ehfmsilva.github.io/rCTOOL/reference/soil_config.md)
  : soil_config
- [`soil_pool_decomposition()`](https://ehfmsilva.github.io/rCTOOL/reference/soil_pool_decomposition.md)
  : soil_pool_decomposition
- [`turnover()`](https://ehfmsilva.github.io/rCTOOL/reference/turnover.md)
  : turnover
- [`turnover_beta()`](https://ehfmsilva.github.io/rCTOOL/reference/turnover_beta.md)
  : turnover_beta
- [`update_monthly_FOM_sub()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_FOM_sub.md)
  : update_monthly_FOM_sub
- [`update_monthly_FOM_top()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_FOM_top.md)
  : update_monthly_FOM_top
- [`update_monthly_HUM_sub()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_HUM_sub.md)
  : update_monthly_HUM_sub
- [`update_monthly_HUM_top()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_HUM_top.md)
  : update_monthly_HUM_top
- [`update_monthly_ROM_sub()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_ROM_sub.md)
  : update_monthly_ROM_sub
- [`update_monthly_ROM_top()`](https://ehfmsilva.github.io/rCTOOL/reference/update_monthly_ROM_top.md)
  : update_monthly_ROM_top
