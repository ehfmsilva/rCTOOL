# initialize_soil_pools

Initialize topsoil and subsoil carbon pools.

## Usage

``` r
initialize_soil_pools(cn, soil_config)
```

## Arguments

- cn:

  Soil carbon:nitrogen ratio.

- soil_config:

  Soil configuration list.

## Value

A list containing initialized topsoil and subsoil pools.

## Examples

``` r
s_config <- soil_config()
initialize_soil_pools(cn=15, soil_config = s_config)
#> [[1]]
#> [[1]]$FOM_top
#> [1] 0.99264
#> 
#> [[1]]$HUM_top
#> [1] 9.184465
#> 
#> [[1]]$ROM_top
#> [1] 22.9109
#> 
#> 
#> [[2]]
#> [[2]]$FOM_sub
#> [1] 0.1231296
#> 
#> [[2]]$HUM_sub
#> [1] 6.732017
#> 
#> [[2]]$ROM_sub
#> [1] 30.45685
#> 
#> 
```
