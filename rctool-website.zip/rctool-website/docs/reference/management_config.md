# management_config

Prepares management configuration for monthly carbon input allocation.

## Usage

``` r
management_config(
  management_filepath = NULL,
  plant_monthly_allocation = NULL,
  grain_monthly_allocation = NULL,
  grass_monthly_allocation = NULL,
  manure_monthly_allocation = NULL,
  f_man_humification = 0.12
)
```

## Arguments

- management_filepath:

  Either a filepath to a management template or a data.frame containing
  management allocation variables.

- plant_monthly_allocation:

  Monthly distribution of plant carbon inputs.

- grain_monthly_allocation:

  Monthly distribution of grain carbon inputs.

- grass_monthly_allocation:

  Monthly distribution of grass carbon inputs.

- manure_monthly_allocation:

  Monthly distribution of manure carbon inputs.

- f_man_humification:

  Fraction of manure already humidified.

## Value

A list containing management allocation settings.

## Details

This function can be used in two ways: 1. from a management template
file or data.frame, such as one exported with
\`export_management_template()\` 2. by directly providing fixed monthly
allocation vectors of length 12.

In the first approach, the user can specify monthly allocation fractions
directly in the input file. When no crop rotation is considered,
\`plant_monthly_allocation\` should be used. When crop rotation is
considered, grain and grass allocation fractions can be specified
separately.

In the second approach, the user can directly provide monthly allocation
vectors of length 12.

## Examples

``` r
management_config(
f_man_humification=0.192,
plant_monthly_allocation = c(0,0,0,.08,.12,.16,.64,0,0,0,0,0),
 manure_monthly_allocation = c(0,0,1,0,0,0,0,0,0,0,0,0)
 )
#> $f_man_humification
#> [1] 0.192
#> 
#> $plant_monthly_allocation
#>  [1] 0.00 0.00 0.00 0.08 0.12 0.16 0.64 0.00 0.00 0.00 0.00 0.00
#> 
#> $grain_monthly_allocation
#> NULL
#> 
#> $grass_monthly_allocation
#> NULL
#> 
#> $manure_monthly_allocation
#>  [1] 0 0 1 0 0 0 0 0 0 0 0 0
#> 
```
