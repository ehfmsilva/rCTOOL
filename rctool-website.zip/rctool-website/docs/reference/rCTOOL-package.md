# rCTOOL package

Provides an 'R' interface to the 'C-TOOL' soil carbon turnover model for
simulating soil organic carbon dynamics in agricultural systems. The
package supports the definition of carbon inputs, management schedules,
soil parameters, and temperature forcing, and includes tools for
scenario analysis and calibration of selected model parameters against
observed soil organic carbon stocks. The 'C-TOOL' model and related
modelling framework are described by Petersen et al. (2002)
[doi:10.1016/S0304-3800(02)00034-0](https://doi.org/10.1016/S0304-3800%2802%2900034-0)
, Petersen et al. (2005)
[doi:10.1016/j.soilbio.2004.08.006](https://doi.org/10.1016/j.soilbio.2004.08.006)
, Petersen et al. (2013)
[doi:10.1016/j.jclepro.2013.03.007](https://doi.org/10.1016/j.jclepro.2013.03.007)
, and Taghizadeh-Toosi et al. (2014)
[doi:10.1016/j.ecolmodel.2014.08.016](https://doi.org/10.1016/j.ecolmodel.2014.08.016)
. Further applications and developments are described by
Taghizadeh-Toosi et al. (2016)
[doi:10.1016/j.agsy.2016.03.004](https://doi.org/10.1016/j.agsy.2016.03.004)
, Keel et al. (2017)
[doi:10.1111/ejss.12454](https://doi.org/10.1111/ejss.12454) ,
Taghizadeh-Toosi et al. (2020)
[doi:10.1007/s11104-020-04500-9](https://doi.org/10.1007/s11104-020-04500-9)
, and Taghizadeh-Toosi and Christensen (2021)
[doi:10.1038/s41598-021-97744-z](https://doi.org/10.1038/s41598-021-97744-z)
.

## Author

**Maintainer**: Franca Giannini-Kurina <francagk@agro.au.dk>

Authors:

- Evandro H. Figueiredo Moura da Silva <ehfmsilva@agro.au.dk>

- João Serra
