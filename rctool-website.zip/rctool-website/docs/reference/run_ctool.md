# run_ctool

Run C-TOOL over the full simulation period.

## Usage

``` r
run_ctool(
  time_config,
  cin_config,
  m_config,
  t_config,
  s_config,
  soil_pools,
  verbose = FALSE
)
```

## Arguments

- time_config:

  Time configuration object created by \`define_timeperiod()\`.

- cin_config:

  Carbon input configuration.

- m_config:

  Management configuration with monthly allocation patterns.

- t_config:

  Monthly temperature configuration containing at least \`month\` and
  \`Tavg\`.

- s_config:

  Soil parameter configuration.

- soil_pools:

  Initial soil pool configuration.

- verbose:

  Logical; if \`TRUE\`, run balance checking.

## Value

A data.frame containing the monthly simulation output across the full
simulation period.

## Details

Iteratively applies \`turnover()\` over all timesteps defined in
\`time_config\` and returns monthly carbon pool sizes, soil carbon
stocks, transport fluxes and CO2 emissions.

The temperature configuration must provide monthly mean air temperature.
A single historical annual temperature amplitude is calculated
internally from the monthly climatology of \`Tavg\` and is used in the
soil temperature response function.
