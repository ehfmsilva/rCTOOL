# rCTOOL scenario example dataset

Example dataset used to demonstrate scenario simulations in rCTOOL.

## Usage

``` r
scenario
```

## Format

A data frame.

## Source

Internal example dataset distributed with rCTOOL.
