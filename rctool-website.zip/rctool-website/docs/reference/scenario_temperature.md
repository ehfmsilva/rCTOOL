# rCTOOL scenario temperature dataset

Monthly temperature dataset used in rCTOOL scenario simulations.

## Usage

``` r
scenario_temperature
```

## Format

A data frame.

## Source

Internal example dataset distributed with rCTOOL.
