# set_monthly_temperature_data

Prepare monthly temperature input data for rCTOOL.

## Usage

``` r
set_monthly_temperature_data(file = NULL, Tavg = NULL)
```

## Arguments

- file:

  Either a filepath to a csv file or a data.frame containing monthly
  temperature data.

- Tavg:

  Numeric vector of average monthly temperature values.

## Value

A data.frame containing monthly temperature input data. The output
always contains \`Tavg\`.

## Details

Monthly temperature data can be provided in two ways: 1. directly
through the argument \`file\`, as a filepath or data.frame containing
monthly temperature data 2. directly through the argument \`Tavg\`, as a
numeric vector of average monthly temperature values

## Examples

``` r
df_temp <- data.frame(Tavg = c(5, 6, 7, 8, 9, 15, 14, 11, 10, 9, 5, 1))
set_monthly_temperature_data(file = df_temp)
#>    Tavg
#> 1     5
#> 2     6
#> 3     7
#> 4     8
#> 5     9
#> 6    15
#> 7    14
#> 8    11
#> 9    10
#> 10    9
#> 11    5
#> 12    1

set_monthly_temperature_data(
  Tavg = c(5, 6, 7, 8, 9, 15, 14, 11, 10, 9, 5, 1)
)
#>    Tavg
#> 1     5
#> 2     6
#> 3     7
#> 4     8
#> 5     9
#> 6    15
#> 7    14
#> 8    11
#> 9    10
#> 10    9
#> 11    5
#> 12    1
```
