# set_monthly_temperature_data_historical_amplitude

Prepare monthly temperature input with a single historical amplitude.

## Usage

``` r
set_monthly_temperature_data_historical_amplitude(file = NULL, Tavg = NULL)
```

## Arguments

- file:

  Either a filepath to a csv file or a data.frame containing monthly
  temperature data.

- Tavg:

  Numeric vector of average monthly temperature values.

## Value

A data.frame containing \`Tavg\` and a single historical \`Amplitude\`
repeated over the full series.

## Details

Monthly \`Tavg\` data can be provided either as a filepath/data.frame
through \`file\` or directly as a numeric vector through \`Tavg\`.

A single historical amplitude is calculated from the full monthly
\`Tavg\` series as: \$\$(max(Tavg) - min(Tavg)) / 2\$\$

This historical amplitude is then assigned to the full series in the
\`Amplitude\` column.

## Examples

``` r
set_monthly_temperature_data_historical_amplitude(
  Tavg = c(1, 2, 4, 7, 11, 15, 17, 16, 13, 9, 5, 2)
)
#>    Tavg Amplitude
#> 1     1         8
#> 2     2         8
#> 3     4         8
#> 4     7         8
#> 5    11         8
#> 6    15         8
#> 7    17         8
#> 8    16         8
#> 9    13         8
#> 10    9         8
#> 11    5         8
#> 12    2         8
```
