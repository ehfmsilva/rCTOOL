# soil_config

Prepare soil configuration parameters.

## Usage

``` r
soil_config(
  Csoil_init = 70.4,
  f_hum_top = 0.48,
  f_rom_top = 0.49,
  f_hum_sub = 0.312,
  f_rom_sub = 0.6847,
  Cproptop = 0.47,
  clay_top = 0.1,
  clay_sub = 0.15,
  phi = 0.035,
  f_co2 = 0.628,
  f_romi = 0.012,
  k_fom = 0.12,
  k_hum = 0.0028,
  k_rom = 3.85e-05,
  ftr = 0.0025,
  temp_method = "rctool",
  temp_amplitude_hist = NA_real_,
  temp_offset = 0,
  temp_th_diff = 3.5e-07
)
```

## Arguments

- Csoil_init:

  Initial carbon stock at depth 1m (Mg C ha-1).

- f_hum_top:

  Initial HUM fraction in the topsoil layer.

- f_rom_top:

  Initial ROM fraction in the topsoil layer.

- f_hum_sub:

  Initial HUM fraction in the bottom layer.

- f_rom_sub:

  initial ROM fraction in the bottom layer.

- Cproptop:

  Proportion of the total carbon allocated to the topsoil.

- clay_top:

  Clay fraction in the top soil.

- clay_sub:

  Clay fraction in the subsoil.

- phi:

  Legacy diffusion parameter used in the original rCTOOL temperature
  formulation.

- f_co2:

  Respiration fraction.

- f_romi:

  Romification fraction.

- k_fom:

  FOM decomposition rate constant.

- k_hum:

  HUM decomposition rate constant.

- k_rom:

  ROM decomposition rate constant.

- ftr:

  Vertical transport rate.

- temp_method:

  Temperature method identifier.

- temp_amplitude_hist:

  Optional historical annual amplitude to be used in the soil
  temperature calculation.

- temp_offset:

  Phase offset used in the soil temperature calculation.

- temp_th_diff:

  Thermal diffusivity used in the physical soil temperature formulation.

## Value

A list containing soil configuration parameters.

## Details

Exports a template that can be used to provide management inputs for the
model. The exported file includes monthly allocation variables and
carbon input columns initialized with zeros, so they can be filled by
the user before being read by the model.

Users should keep only the columns relevant to their workflow and avoid
double accounting among allocation variables. For example, when
\`plant_monthly_allocation\` is used, grain and grass allocation columns
should not be used simultaneously.

If monthly carbon inputs are provided directly, additional allocation
columns may not be needed. These consistency checks are not enforced
automatically and must be handled by the user when preparing the input
file.

## Examples

``` r
soil_config(Csoil_init=72, f_hum_top=0.5, clay_sub = 0.35, clay_top=0.25)
#> $Csoil_init
#> [1] 72
#> 
#> $f_hum_top
#> [1] 0.5
#> 
#> $f_rom_top
#> [1] 0.49
#> 
#> $f_hum_sub
#> [1] 0.312
#> 
#> $f_rom_sub
#> [1] 0.6847
#> 
#> $Cproptop
#> [1] 0.47
#> 
#> $clay_top
#> [1] 0.25
#> 
#> $clay_sub
#> [1] 0.35
#> 
#> $phi
#> [1] 0.035
#> 
#> $f_co2
#> [1] 0.628
#> 
#> $f_romi
#> [1] 0.012
#> 
#> $k_fom
#> [1] 0.12
#> 
#> $k_hum
#> [1] 0.0028
#> 
#> $k_rom
#> [1] 3.85e-05
#> 
#> $ftr
#> [1] 0.0025
#> 
#> $ini_Cin_top
#> [1] 33.84
#> 
#> $ini_Cin_sub
#> [1] 38.16
#> 
#> $temp_method
#> [1] "rctool"
#> 
#> $temp_amplitude_hist
#> [1] NA
#> 
#> $temp_offset
#> [1] 0
#> 
#> $temp_th_diff
#> [1] 3.5e-07
#> 
```
