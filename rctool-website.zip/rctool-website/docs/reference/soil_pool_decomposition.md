# soil_pool_decomposition

Calculate temperature-modified decomposition of a soil carbon pool.

## Usage

``` r
soil_pool_decomposition(
  soil_pool,
  k,
  soil_depth,
  month,
  t_avg,
  amplitude,
  s_config
)
```

## Arguments

- soil_pool:

  Carbon amount in the soil pool.

- k:

  First-order decomposition rate constant.

- soil_depth:

  Soil layer thickness in cm. In the default C-TOOL configuration, the
  model operates with two fixed layers: topsoil (25 cm) and subsoil (100
  cm).

- month:

  Month index from 1 to 12.

- t_avg:

  Monthly mean air temperature.

- amplitude:

  Historical annual temperature amplitude previously calculate from the
  monthly temperature series.

- s_config:

  Soil parameter configuration.

## Value

Carbon change in the pool due to temperature-modified first-order
decomposition.
