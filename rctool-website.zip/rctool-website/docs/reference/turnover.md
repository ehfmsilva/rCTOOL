# turnover

Perform one monthly turnover step of C-TOOL.

## Usage

``` r
turnover(
  timestep,
  time_config,
  cin_config,
  m_config,
  t_config,
  s_config,
  out,
  amplitude_hist
)
```

## Arguments

- timestep:

  Integer index of the simulation timestep.

- time_config:

  Time configuration object created by \`define_timeperiod()\`.

- cin_config:

  Carbon input configuration.

- m_config:

  Management configuration with monthly allocation patterns.

- t_config:

  Monthly temperature configuration containing at least \`month\` and
  \`Tavg\`.

- s_config:

  Soil parameter configuration.

- out:

  Data frame containing pool values from the previous timestep.

- amplitude_hist:

  Numeric. Historical annual air temperature amplitude calculated from
  the monthly climatology of \`Tavg\`.

## Value

A data.frame containing updated monthly pool sizes, carbon stocks,
transport fluxes and CO2 emissions for the current timestep.

## Details

Updates FOM, HUM and ROM pools for one monthly timestep using carbon
inputs, management allocations, monthly mean air temperature, soil
parameters, and the previous pool state.
