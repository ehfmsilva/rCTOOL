# turnover_beta

Legacy monthly turnover routine retained for backward compatibility.

## Usage

``` r
turnover_beta(i)
```

## Arguments

- i:

  Integer index of the simulation timestep.

## Value

A one-row data.frame containing updated pool sizes, carbon stocks,
transport fluxes and CO2 emissions for the current timestep.

## Details

This function updates FOM, HUM and ROM pools for one monthly timestep
using the historical C-TOOL workflow. It relies on objects defined in
the calling environment and is retained only for backward compatibility.
