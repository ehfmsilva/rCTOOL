# update_monthly_FOM_sub

update_monthly_FOM_sub

## Usage

``` r
update_monthly_FOM_sub(
  FOM_sub_t1,
  FOM_transport,
  C_in_plant_sub,
  month,
  m_config
)
```

## Arguments

- FOM_sub_t1:

  FOM content in the subsoil layer from the previous timestep.

- FOM_transport:

  FOM transported from the topsoil.

- C_in_plant_sub:

  Plant carbon input to the subsoil.

- month:

  Month index from 1 to 12.

- m_config:

  Management configuration list.

## Value

Updated FOM content in the subsoil layer after plant inputs and
transport from the topsoil.
