# update_monthly_FOM_top

update_monthly_FOM_top

## Usage

``` r
update_monthly_FOM_top(FOM_top_t1, Cin_plant_top, Cin_manure, month, m_config)
```

## Arguments

- FOM_top_t1:

  FOM content in the topsoil layer from the previous timestep.

- Cin_plant_top:

  Plant carbon input to the topsoil.

- Cin_manure:

  Manure carbon input.

- month:

  Month index from 1 to 12.

- m_config:

  Management configuration list.

## Value

Updated FOM content in the topsoil layer after monthly carbon inputs.
