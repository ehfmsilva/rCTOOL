# update_monthly_HUM_sub

update_monthly_HUM_sub

## Usage

``` r
update_monthly_HUM_sub(HUM_sub_t1, HUM_transport, FOM_humified_sub)
```

## Arguments

- HUM_sub_t1:

  HUM content in the subsoil layer from the previous timestep.

- HUM_transport:

  HUM transported from the topsoil.

- FOM_humified_sub:

  Humified FOM added to the subsoil HUM pool.

## Value

Updated HUM content in the subsoil layer after transport and humified
FOM additions.
