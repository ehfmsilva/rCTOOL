# update_monthly_HUM_top

update_monthly_HUM_top

## Usage

``` r
update_monthly_HUM_top(HUM_top_t1, C_in_man, FOM_humified_top, month, m_config)
```

## Arguments

- HUM_top_t1:

  HUM content in the topsoil layer from the previous timestep.

- C_in_man:

  Manure carbon input.

- FOM_humified_top:

  Humified FOM added to the topsoil HUM pool.

- month:

  Month index from 1 to 12.

- m_config:

  Management configuration list.

## Value

Updated HUM content in the topsoil layer after manure inputs and
humified FOM additions.
