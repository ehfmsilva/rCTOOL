# update_monthly_ROM_sub

update_monthly_ROM_sub

## Usage

``` r
update_monthly_ROM_sub(ROM_sub_t1, HUM_romified_sub, ROM_transport)
```

## Arguments

- ROM_sub_t1:

  ROM content in the subsoil layer from the previous timestep.

- HUM_romified_sub:

  Romified HUM added to the subsoil ROM pool.

- ROM_transport:

  ROM transported from the topsoil.

## Value

Updated ROM content in the subsoil layer after romified HUM additions
and transport from the topsoil.
