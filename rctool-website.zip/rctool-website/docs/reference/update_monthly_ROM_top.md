# update_monthly_ROM_top

update_monthly_ROM_top

## Usage

``` r
update_monthly_ROM_top(ROM_top_t1, HUM_romified_top)
```

## Arguments

- ROM_top_t1:

  ROM content in the topsoil layer from the previous timestep.

- HUM_romified_top:

  Romified HUM added to the topsoil ROM pool.

## Value

Updated ROM content in the topsoil layer after romified HUM additions.
