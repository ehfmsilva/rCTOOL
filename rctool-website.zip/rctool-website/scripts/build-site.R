options(repos = c(CRAN = "https://cloud.r-project.org"))
if (nzchar(Sys.getenv("RCTOOL_SITE_LIBRARY"))) .libPaths(c(Sys.getenv("RCTOOL_SITE_LIBRARY"), .libPaths()))
stopifnot(requireNamespace("curl", quietly = TRUE))
install.packages(".", repos = NULL, type = "source", lib = .libPaths()[1])
source("inst/examples/quick-start.R")
stopifnot(nrow(output) == 69 * 12, all(is.finite(output$SOC_stock)))
stopifnot(max(abs(output$SOC_stock - output$C_topsoil - output$C_subsoil)) < 1e-8)
p <- ggplot(output, aes(date, C_topsoil)) +
  geom_line(colour = "#aa4e35", linewidth = 0.65) +
  labs(x = "Year", y = expression("Topsoil SOC (Mg C " * ha^{-1} * ")")) +
  theme_classic(base_size = 13)
ggplot2::ggsave("man/figures/site-basic-soc.png", p, width = 8, height = 4.4, dpi = 160)
pkgdown::build_site(new_process = FALSE, install = FALSE, examples = TRUE, preview = FALSE)
source("scripts/finalize-assets.R")
file.copy("inst/examples/quick-start.R", "docs/quick-start.R", overwrite = TRUE)
file.create("docs/.nojekyll")
cat("RCTOOL_SITE_BUILD_OK\n")
