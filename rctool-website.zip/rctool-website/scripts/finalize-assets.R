# Keep search navigation on the current host, including local previews.
search <- jsonlite::read_json("docs/search.json")
search <- lapply(search, function(entry) {
  entry$path <- sub("^https://ehfmsilva.github.io", "", entry$path)
  if (is.null(entry$id)) entry$id <- "main"
  entry
})
jsonlite::write_json(search, "docs/search.json", auto_unbox = TRUE, null = "null")

# Keep site branding and source links consistent on all generated pages.
cran_commit <- "10cf1b8717ea3173a6979c25764af1598a22c747"
cran_tree <- paste0("https://github.com/cran/rCTOOL/tree/", cran_commit)
cran_blob <- paste0("https://github.com/cran/rCTOOL/blob/", cran_commit, "/")
file.copy("pkgdown/extra.css", "docs/extra.css", overwrite = TRUE)
for (page in list.files("docs", pattern = "\\.html$", recursive = TRUE, full.names = TRUE)) {
  html <- xml2::read_html(page)
  brand <- xml2::xml_find_first(html, "//a[contains(concat(' ', normalize-space(@class), ' '), ' navbar-brand ')]")
  if (inherits(brand, "xml_missing")) next
  prefix <- sub("index.html$", "", xml2::xml_attr(brand, "href"))
  logo <- paste0(prefix, "reference/figures/rCTOOLicon.jpg")
  xml2::xml_remove(xml2::xml_find_all(brand, "./img[contains(@class, 'rctool-navbar-logo')]"))
  xml2::xml_add_child(brand, "img", src = logo, alt = "", width = "26", height = "30",
                     class = "rctool-navbar-logo", .where = 0)
  head <- xml2::xml_find_first(html, "//head")
  xml2::xml_remove(xml2::xml_find_all(head, "./link[@rel='icon']"))
  xml2::xml_add_child(head, "link", rel = "icon", type = "image/jpeg", href = logo)
  source_links <- xml2::xml_find_all(html, "//a[normalize-space(.)='Browse source code' or @aria-label='GitHub']")
  xml2::xml_set_attr(source_links, "href", cran_tree)
  xml2::xml_set_attr(source_links, "title", "Source for rCTOOL 3.1.0 (CRAN mirror)")
  file_links <- xml2::xml_find_all(html, "//a[starts-with(@href, 'https://github.com/francagiannini/rCTOOL/blob/HEAD/')]")
  for (link in file_links) {
    target <- sub("^https://github.com/francagiannini/rCTOOL/blob/HEAD/", cran_blob, xml2::xml_attr(link, "href"))
    xml2::xml_set_attr(link, "href", target)
  }
  xml2::write_html(html, page)
}

# Use the author's requested surname and initials in the displayed citation.
for (page in c("docs/authors.html", "docs/authors.md", "docs/search.json")) {
  if (!file.exists(page)) next
  text <- readLines(page, warn = FALSE, encoding = "UTF-8")
  text <- gsub("Silva EHFMd, Serra", "Figueiredo Moura da Silva, EH, Serra", text, fixed = TRUE)
  text <- gsub("Figueiredo Moura da Silva EH, Serra", "Figueiredo Moura da Silva, EH, Serra", text, fixed = TRUE)
  text <- gsub("author = {Evandro H. Figueiredo Moura da Silva and", "author = {Figueiredo Moura da Silva, Evandro H. and", text, fixed = TRUE)
  writeLines(text, page, useBytes = TRUE)
}
