# Keep search navigation on the current host, including local previews.
search <- jsonlite::read_json("docs/search.json")
search <- lapply(search, function(entry) {
  entry$path <- sub("^https://ehfmsilva.github.io", "", entry$path)
  if (is.null(entry$id)) entry$id <- "main"
  entry
})
jsonlite::write_json(search, "docs/search.json", auto_unbox = TRUE, null = "null")
